package com.example.fastnumemes;

public class Profile {

    String pic;
    String username;

    public Profile(String pic,String username) {
        this.username = username;
        this.pic=pic;
    }
}
