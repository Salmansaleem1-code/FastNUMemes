package com.example.fastnumemes;


public class Register {
String username;
String email;
int value;
String password;
    Register(String username,String password,int value){
        this.username=username;
        this.password=password;
        this.value=value;



    }

}
