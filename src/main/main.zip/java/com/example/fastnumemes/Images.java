package com.example.fastnumemes;

import android.widget.Button;
import android.widget.ImageView;

public class Images {

   int imageid;
   String name;
    int btnid;
     int btnid2;
    public Images(int imageid,String name,int btnid,int btnid2) {
        this.name=name;
        this.imageid = imageid;
        this.btnid=btnid;
        this.btnid2=btnid2;
    }
}
